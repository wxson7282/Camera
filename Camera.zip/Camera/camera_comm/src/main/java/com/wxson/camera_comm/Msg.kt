package com.wxson.camera_comm

/**
 * @author wxson
 * @date 2022/8/19
 * @apiNote
 */
class Msg(val type: String, val obj: Any? )